## DEVELOPMENT

The source code is primarily in `./bin/autojump`. Various shell wrapper scripts
are also available in `./bin/`.

Documentation is in various files under `./docs/`. Build documentation with the
command:

    make docs

Unit tests are available in `./tests/`. Run unit tests with the command:

    make test
