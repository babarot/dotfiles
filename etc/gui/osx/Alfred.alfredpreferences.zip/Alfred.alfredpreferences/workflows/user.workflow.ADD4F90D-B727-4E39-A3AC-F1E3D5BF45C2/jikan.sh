#!/bin/bash

LANG=C

cd "$(dirname "${BASH_SOURCE}")";

if [ -x `which qlmanage` ]; then
	qlmanage -p $(date +'%a' | tr [A-Z] [a-z]).png >/dev/null 2>&1
elif [ -x `which open` ]; then
	open $(date +'%a' | tr [A-Z] [a-z]).png
fi
