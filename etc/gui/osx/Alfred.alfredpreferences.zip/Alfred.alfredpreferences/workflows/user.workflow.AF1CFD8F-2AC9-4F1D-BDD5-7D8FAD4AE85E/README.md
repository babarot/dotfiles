Hash text for Alfred 2
============

A simple Alfred 2 string hash workflow's.


Installation
----------------

- Download "[Hash.alfredworkflow](https://github.com/BigLuck/alfred2-hash/raw/master/Hash.alfredworkflow)" extension.
- Double click the downloaded "Hash.alfredworkflow" file to install.
*Alfred 2 is required*


Instructions
----------------

- md5 `<string>`
- sha1 `<string>`
- htpasswd `<string>`
- crc32 `<string>`
- whirlpool `<string>`
- base64_decode `<string>`
- base64_encode `<string>`